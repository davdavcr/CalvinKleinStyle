﻿namespace Proyecto.Migrations
{
    using System;
    using System.Data.Entity.Migrations;

    public partial class CrearTablaUsuario : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.Usuario",
                c => new
                {
                    Id = c.Int(nullable: false, identity: true),
                    Nombre = c.String(),
                    Cedula = c.String(),
                    Genero = c.String(),
                    FechaRegistro = c.DateTime(nullable: false),
                    Estado = c.String(),
                    NombreUsuario = c.String(),
                    Contrasena = c.String(),
                    Rol = c.String(),
                })
                .PrimaryKey(t => t.Id);
        }

        public override void Down()
        {
            DropTable("dbo.Usuario");
        }
    }
}
