﻿namespace Proyecto.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class AgregarTablaFacturas : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.Facturas",
                c => new
                    {
                        Id = c.Int(nullable: false, identity: true),
                        CedulaCliente = c.String(),
                        NombreCliente = c.String(),
                        CodigoProducto = c.String(),
                        NombreProducto = c.String(),
                        FechaFactura = c.String(),
                        CantidadProducto = c.Double(nullable: false),
                        MontoTotal = c.Double(nullable: false),
                    })
                .PrimaryKey(t => t.Id);
            
        }
        
        public override void Down()
        {
            DropTable("dbo.Facturas");
        }
    }
}
