﻿namespace Proyecto.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class CambiarPrecioADouble : DbMigration
    {
        public override void Up()
        {
            AlterColumn("dbo.Productos", "Precio", c => c.Double(nullable: false));
        }
        
        public override void Down()
        {
            AlterColumn("dbo.Productos", "Precio", c => c.Int(nullable: false));
        }
    }
}
