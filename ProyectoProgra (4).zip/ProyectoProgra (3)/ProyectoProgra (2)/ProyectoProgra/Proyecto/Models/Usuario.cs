﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Proyecto.Models
{
    [Table("Usuario")]
    public class Usuario
    {
        private int id;
        private string nombre, cedula, genero, estado, nombreUsuario, contrasena, rol;
        private DateTime fechaRegistro;

        public int Id { get => id; set => id = value; }
        public string Nombre { get => nombre; set => nombre = value; }
        public string Cedula { get => cedula; set => cedula = value; }
        public string Genero { get => genero; set => genero = value; }
        public string Estado { get => estado; set => estado = value; }
        public string NombreUsuario { get => nombreUsuario; set => nombreUsuario = value; }
        public string Contrasena { get => contrasena; set => contrasena = value; }
        public string Rol { get => rol; set => rol = value; }
        public DateTime FechaRegistro { get => fechaRegistro; set => fechaRegistro = value; }

        [NotMapped]
        [Compare("Contrasena", ErrorMessage = "La contraseña y la confirmación no coinciden.")]
        [DataType(DataType.Password)]
        public string ConfirmarContrasena { get; set; }

        public Usuario(int id, string nombre, string cedula, string genero, string estado, string nombreUsuario, string contrasena, string rol, DateTime fechaRegistro)
        {
            this.id = id;
            this.nombre = nombre;
            this.cedula = cedula;
            this.genero = genero;
            this.estado = estado;
            this.nombreUsuario = nombreUsuario;
            this.contrasena = contrasena;
            this.rol = rol;
            this.fechaRegistro = fechaRegistro;
            this.ConfirmarContrasena = "";
        }

        public Usuario()
        {
            this.id = 0;
            this.nombre = "";
            this.cedula = "";
            this.genero = "";
            this.estado = "";
            this.nombreUsuario = "";
            this.contrasena = "";
            this.rol = "";
            this.fechaRegistro = DateTime.Now;
            this.ConfirmarContrasena = "";
        }
    }
}