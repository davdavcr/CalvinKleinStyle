﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Proyecto.Models;

namespace Proyecto.Controllers
{

 
    public class UsuarioController : Controller
    {
        private Service service = new Service();
        // GET: UsuarioController
        public ActionResult Index()
        {
            var usuarios = service.MostrarUsuarios();
            return View(usuarios);
        }

        //GET: UsuarioController/Details/5
        public ActionResult Details(string cedula)
        {
            var usuario = service.ObtenerUsuarioPorCedula(cedula); // Obtener usuario por cédula
            if (usuario == null)
            {
                return NotFound();
            }
            return View(usuario);
        }


        // GET: UsuarioController/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: UsuarioController/Create
        [HttpPost]
[ValidateAntiForgeryToken]
public ActionResult Create(Usuario usuario)
{
    try
    {
        if (ModelState.IsValid)
        {
            usuario.FechaRegistro = DateTime.Now; // Asegurar que venga con valor válido
            service.AgregarUsuario(usuario);
            TempData["Mensaje"] = "Usuario agregado correctamente.";
            return RedirectToAction(nameof(Index));
        }
    }
    catch (Exception ex)
    {
        ModelState.AddModelError("", "Error al guardar: " + ex.Message);
    }

    return View(usuario);
}

        // GET: UsuarioController/Edit/5
        public ActionResult Edit(int id)
        {

            var usuario = service.ObtenerUsuarioPorId(id);
            if (usuario == null)
            {
                return NotFound();
            }
            return View(usuario);
        }

        // POST: UsuarioController/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(Usuario usuario)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    service.EditarUsuario(usuario);
                    return RedirectToAction("Index");
                }
            }
            catch
            {
                return View(usuario);
            }
            return View(usuario);
        }

        // GET: UsuarioController/Delete/5
        public ActionResult Delete(int id)
        {
            var usuario = service.ObtenerUsuarioPorId(id);
            if (usuario == null)
            {
                return NotFound();
            }
            return View(usuario);
        }
        

        // POST: UsuarioController/Delete/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Delete(int id, IFormCollection collection)
        {
            var usuario = service.ObtenerUsuarioPorId(id);
            if (usuario == null)
            {
                return NotFound();
            }

            try
            {
                service.EliminarUsuario(id);
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View(usuario);
            }
        }

        //GET: UsuarioController/Login
        public ActionResult Login()
        {
            if (!string.IsNullOrEmpty(HttpContext.Session.GetString("Nombre")))
                HttpContext.Session.Clear();
          
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Login(string usuario, string pass)
        {
            try
            {
                var usuarioLogueado = service.ValidaLogin(usuario, pass);

                if (usuarioLogueado == null)
                {
                    ViewBag.Error = "Usuario o contraseña incorrectos.";
                    return View();
                }

                // Si no es null, da paso a la sesión
                HttpContext.Session.SetString("Nombre", usuarioLogueado.Nombre);
                HttpContext.Session.SetString("Rol", usuarioLogueado.Rol);
                return RedirectToAction("Index", "Home");
            }
            catch (Exception ex)
            {
                ViewBag.Error = "Error al iniciar sesión: " + ex.Message;
                return View();
            }
        }


    }
}
